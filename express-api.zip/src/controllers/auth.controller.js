import dataSource from '../config/db.config.js'
import User       from '../entities/user.js'

export const signIn = async (req, res, next) => {
	const {id, password} = req.body

	const userRepository = dataSource.getRepository(User)

	try {
		const user = await userRepository.findOne({where: {id}})
	} catch (error) {

	}
}


export const signUp = async (req, res, next) => {

}


export const newToken = async (req, res, next) => {

}


export const info = async (req, res, next) => {

}


export const logout = async (req, res, next) => {

}

