import {EntitySchema} from 'typeorm'

export default new EntitySchema({
	name: 'User',
	tableName: 'users',
	columns: {
		id: {
			primary: true,
			type: 'varchar',
		},
		password: {
			type: 'varchar'
		}
	}
})