import {Router}                                 from 'express'
import checkJwt                                 from '../middleware/checkJwt.js'
import {signIn, signUp, info, logout, newToken} from '../controllers/auth.controller.js'

const router = Router()

router.post('/signin', signIn)
router.post('/signin/new_token', checkJwt, newToken)
router.post('/signup', signUp)

export default router