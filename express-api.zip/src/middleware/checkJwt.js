import jwt from 'jsonwebtoken'

export default (req, res, next) => {
}